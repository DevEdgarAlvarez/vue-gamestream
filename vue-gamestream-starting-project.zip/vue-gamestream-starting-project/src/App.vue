<script setup>
import LayoutHero from './components/Layout/LayoutHero.vue';
</script>

<template>
  <LayoutHero />
  <main></main>
</template>

<style scoped>
main {
  padding: 2rem;
}
</style>
